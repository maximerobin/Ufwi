from ufwi_authd_cmd.client import NuauthError, Client
from ufwi_authd_cmd.version import VERSION as __revision__

