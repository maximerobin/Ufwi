VERSION = "0.1"
WEBSITE = "http://software.inl.fr/trac/trac.cgi/wiki/EdenWall/NuFW"
LICENSE = 'GNU GPL v2'

